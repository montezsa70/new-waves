package dev.lelonio.square.ui.components

import androidx.compose.foundation.layout.height
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.font.FontWeight
import dev.lelonio.square.ui.theme.Poppins
import dev.lelonio.square.ui.theme.Ink

/**
 * A page title, set in Waves' display serif.
 *
 * Square drew these in right-angled capitals; Waves sets them in sentence case
 * in Bold Poppins, the same face as every other head in the app. The signature is unchanged so that
 * every tab header keeps calling it as before.
 *
 * [height] is still the old capitals' measure; the type's size is taken from
 * it, which keeps the header's row exactly as tall as it was.
 */
@Composable
fun SquareTitle(
    text: String,
    height: Dp,
    modifier: Modifier = Modifier,
    color: Color = Ink,
) {
    val size = with(LocalDensity.current) { (height * 1.85f).toSp() }
    Text(
        text,
        modifier = modifier.semantics { heading() },
        color = color,
        fontFamily = Poppins,
        fontWeight = FontWeight.Bold,
        letterSpacing = (-0.6).sp,
        fontSize = size,
        lineHeight = size,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
    )
}
